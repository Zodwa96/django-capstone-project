# News Application — Django Capstone Project

A Django news platform where **journalists** write articles, **editors**
review and approve them, and **readers** browse approved articles and
newsletters — via both a web front end and a token-authenticated REST API
(Django REST Framework). Approving an article emails subscribed readers
and notifies the internal API automatically via a Django signal.

## Project layout

```
newsproject/    Project settings, root URL config, WSGI/ASGI entry points
newsapp/        Models, views, forms, admin, signals, and the REST API
templates/      HTML templates for the web front end
docs/           Sphinx documentation source and generated HTML (docs/_build/html)
Dockerfile      Container image definition
docker-compose.yml  App + MariaDB, for one-command local/Docker Playground runs
entrypoint.sh   Container startup script (migrate, setup_permissions, gunicorn)
requirements.txt
```

## Prerequisites

- Python 3.12+
- MariaDB/MySQL server (or use the SQLite fallback described below)
- Docker and Docker Compose, if you want to run the app in containers

## Option 1: Run locally with venv

1. **Create and activate a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure the database.** The app expects a MariaDB/MySQL database
   by default. Create one and set the following environment variables to
   match (defaults shown are placeholders — replace them with your own):
   ```bash
   export DB_NAME=newsdb
   export DB_USER=root
   export DB_PASSWORD=your_password
   export DB_HOST=localhost
   export DB_PORT=3306
   ```
   Then create the database itself:
   ```bash
   mysql -u root -p -e "CREATE DATABASE newsdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   ```

   **No MariaDB/MySQL available?** Skip the two steps above and run with
   the SQLite fallback instead by setting `USE_SQLITE=1` before every
   command below (e.g. `USE_SQLITE=1 python manage.py migrate`).

4. **Apply migrations and set up roles**
   ```bash
   python manage.py migrate
   python manage.py setup_permissions
   python manage.py createsuperuser
   ```

5. **Run the development server**
   ```bash
   python manage.py runserver
   ```
   Visit `http://localhost:8000`.

6. **Run the test suite**
   ```bash
   USE_SQLITE=1 python manage.py test
   ```

### Email and API notification settings (optional)

Approving an article triggers an email to subscribers and a POST to the
app's own `/api/approved/` endpoint. By default, email is sent to the
console (no real email is sent). To send real email, set:
```bash
export EMAIL_HOST_USER=your_email@gmail.com
export EMAIL_HOST_PASSWORD=your_app_password   # a Gmail App Password, not your login password
```
and switch `EMAIL_BACKEND` in `newsproject/settings.py` to the SMTP
backend (see the comment above it). **Never commit real credentials** —
keep them in environment variables or an untracked `.env` file, which is
already excluded via `.gitignore`.

## Option 2: Run with Docker

The included `Dockerfile` builds the app image, and `docker-compose.yml`
runs it together with a MariaDB database in one step.

1. **Build and start everything**
   ```bash
   docker compose up --build
   ```
   This starts a `db` container (MariaDB) and a `web` container (the
   Django app served by gunicorn), applies migrations, and runs
   `setup_permissions` automatically via `entrypoint.sh`.

2. **Visit the app** at `http://localhost:8000`.

3. **Create an admin user** (in a second terminal, while the containers
   are running):
   ```bash
   docker compose exec web python manage.py createsuperuser
   ```

4. **Stop everything**
   ```bash
   docker compose down          # add -v to also delete the database volume
   ```

### Building/running just the image (no Compose)

If you only have `docker build`/`docker run` available (e.g. the Docker
Playground), you can run the app against SQLite instead of MariaDB so no
separate database container is needed:
```bash
docker build -t newsapp .
docker run -p 8000:8000 -e USE_SQLITE=1 newsapp
```

### Configuring secrets for Docker

Database and email credentials are read from environment variables (see
`docker-compose.yml`). Override the defaults by exporting them before
running `docker compose up`, or by creating a local `.env` file (already
covered by `.gitignore`, so it will never be committed):
```
DB_NAME=newsdb
DB_USER=newsapp
DB_PASSWORD=change_me
DB_ROOT_PASSWORD=change_me_too
EMAIL_HOST_USER=your_email@gmail.com
EMAIL_HOST_PASSWORD=your_app_password
```

## Documentation

Full auto-generated API documentation (built with Sphinx from the
project's docstrings) is available at `docs/_build/html/index.html` —
open that file directly in a browser, or rebuild it yourself:
```bash
pip install sphinx
USE_SQLITE=1 sphinx-build -b html docs docs/_build/html
```

## Notes on the codebase

This project underwent a round of bug-fixing before this submission,
including: removing a circular/forward-referencing foreign key setup,
resolving a `related_name` clash between subscription fields, adding a
missing `timezone` import used in `Article.save()`, converting two
notification helpers from (incorrect) instance methods into standalone
functions, fixing missing imports in the API views, and switching the
permissions management command to `get_or_create` so it can be re-run
safely.

## Git branches

- `master` — main branch, contains everything merged together
- `docs` — docstrings added file-by-file, plus the generated Sphinx docs
- `container` — Docker/Compose setup for containerised deployment
